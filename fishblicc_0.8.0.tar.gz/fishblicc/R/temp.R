LLB = 25:37
fq=list(c(0,1,2,26,72,66,36,24,12,4,1,1,0))
Linf=c(35, 2)
sel_fun=4
gear_names = "Gill net"
Catch = 1
Mk = NA
ref_length = 30
ma_L = NA
wt_L = NA
a = 1
b = 3
L50 = NA
L95 = NA
NK = NA

blicc_ld <- dl
draws <- df
toler=1.0e-06

ld <- blicc_dat(LLB = 25:37, fq=list(c(0,1,2,26,72,66,36,24,12,4,1,1,0)),
                Linf=c(35, 2), sel_fun=4,
                gear_names = "Gill net")

res <- blicc_mpd(ld)
res <- blicc_fit(ld)
res_rp <- blicc_ref_pts(res, ld)


rp_df <- posterior::as_draws_df(res) |>
  dplyr::select(Linf:`.draw`)

plot_expected_frequency(res_rp, Gear = 1)


blicc_ld <- ld
SSPR_solve(35, 100, 1.5, 1, c(30, 0.01, 0.001),
           0.2, 1, blicc_ld)

Linf=35
Galpha=100
Mk=1.5
Fk=1
Sm=c(30, 0.01, 0.001)
tarSPR = 0.2
vdir = 1

library("flextable")
library("tidyverse")
table_prior(dl) |>
  flextable() |>
  colformat_double(digits=3) |>
  set_caption(as_paragraph("Table ", as.character(1),
                           " : Summary of priors used in the fishblicc model")) |>
  autofit()
